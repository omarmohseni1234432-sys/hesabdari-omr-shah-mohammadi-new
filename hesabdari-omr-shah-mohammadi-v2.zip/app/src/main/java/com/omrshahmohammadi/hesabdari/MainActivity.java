package com.omrshahmohammadi.hesabdari;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout root, content; TextView title;
    int BLUE=Color.rgb(25,118,210), DARK=Color.rgb(35,45,55), LIGHT=Color.rgb(245,247,250);

    @Override public void onCreate(Bundle b){
        super.onCreate(b); getWindow().setStatusBarColor(BLUE);
        db=new DB(this); showHome();
    }
    TextView tv(String s,int size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(DARK);
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); t.setPadding(16,10,16,10);
        t.setTypeface(Typeface.DEFAULT); t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return t;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(15); b.setAllCaps(false);
        b.setTextColor(DARK); b.setBackgroundColor(Color.WHITE); b.setPadding(8,4,8,4);
        b.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return b;
    }
    EditText input(String hint){
        EditText e=new EditText(this); e.setHint(hint); e.setTextSize(16); e.setSingleLine(true);
        e.setPadding(14,4,14,4); e.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return e;
    }
    void base(String name){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(LIGHT);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        title=tv(name,22); title.setTextColor(Color.WHITE); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        title.setGravity(Gravity.CENTER); title.setBackgroundColor(BLUE);
        root.addView(title,new LinearLayout.LayoutParams(-1,62));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(14,14,14,8);
        ScrollView sc=new ScrollView(this); sc.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); sc.addView(content);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(Color.WHITE);
        String[] ns={"خانه","فروش","کالا","مشتری","خرید"};
        for(String n:ns){ Button b=btn(n); nav.addView(b,new LinearLayout.LayoutParams(0,58,1));
            b.setOnClickListener(v->{ if(n.equals("خانه"))showHome(); else if(n.equals("فروش"))showSales(); else if(n.equals("کالا"))showProducts(); else if(n.equals("مشتری"))showCustomers(); else showPurchases();});
        }
        root.addView(nav,new LinearLayout.LayoutParams(-1,64)); setContentView(root);
    }
    void add(TextView v){ content.addView(v,new LinearLayout.LayoutParams(-1,-2)); }
    void card(String s){
        TextView v=tv(s,17); v.setBackgroundResource(com.omrshahmohammadi.hesabdari.R.drawable.bg_card);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,7,0,7); content.addView(v,p);
    }
    String now(){return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());}
    double n(EditText e){try{return Double.parseDouble(e.getText().toString().trim());}catch(Exception x){return 0;}}
    long id(Spinner s){return ((KeyItem)s.getSelectedItem()).id;}
    static class KeyItem { long id; String name; KeyItem(long i,String n){id=i;name=n;} public String toString(){return name;} }

    void showHome(){
        base("حسابداری عمر شاه محمدی");
        add(tv("داشبورد",25));
        double sales=db.scalar("SELECT COALESCE(SUM(total),0) FROM sales");
        double cost=db.scalar("SELECT COALESCE(SUM(cost),0) FROM sales");
        double expenses=db.scalar("SELECT COALESCE(SUM(amount),0) FROM expenses");
        double purchases=db.scalar("SELECT COALESCE(SUM(total),0) FROM purchases");
        double profit=sales-cost-expenses;
        card("💰 فروش کل\n"+money(sales)+" افغانی");
        card("📦 خرید ثبت‌شده\n"+money(purchases)+" افغانی");
        card("📈 سود خالص\n"+money(profit)+" افغانی\n(فروش − بهای جنس فروخته‌شده − هزینه‌ها)");
        card("🏦 بهای جنس فروخته‌شده\n"+money(cost)+" افغانی");
        double debt=db.scalar("SELECT COALESCE(SUM(opening),0)+COALESCE((SELECT SUM(total-paid) FROM sales),0)-COALESCE((SELECT SUM(amount) FROM payments),0) FROM customers");
        card("👥 مانده بدهی مشتریان\n"+money(debt)+" افغانی");
        Button r=btn("گزارش سود و زیان"); r.setOnClickListener(v->showReport()); content.addView(r);
    }
    String money(double x){return String.format(Locale.US,"%,.0f",x);}

    void showProducts(){
        base("کالا و موجودی");
        EditText name=input("نام کالا"); EditText unit=input("واحد (بوتل، کیلو، لیتر...)");
        EditText qty=input("موجودی اولیه"); EditText buy=input("قیمت خرید هر واحد"); EditText sell=input("قیمت فروش هر واحد");
        content.addView(name); content.addView(unit); content.addView(qty); content.addView(buy); content.addView(sell);
        Button add=btn("➕ ثبت کالا"); content.addView(add);
        add.setOnClickListener(v->{ if(name.getText().toString().trim().isEmpty())return;
            SQLiteDatabase d=db.getWritableDatabase(); android.content.ContentValues cv=new android.content.ContentValues();
            cv.put("name",name.getText().toString());cv.put("unit",unit.getText().toString());cv.put("qty",n(qty));cv.put("buy",n(buy));cv.put("sell",n(sell));d.insert("products",null,cv);
            Toast.makeText(this,"کالا ثبت شد",Toast.LENGTH_SHORT).show(); showProducts();
        });
        add(tv("موجودی فعلی",20));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,unit,qty,buy,sell FROM products ORDER BY id DESC",null);
        while(c.moveToNext()){
            long pid=c.getLong(0); String s=c.getString(1)+" | "+c.getString(2)+"\nموجودی: "+money(c.getDouble(3))+
                    "\nخرید: "+money(c.getDouble(4))+" | فروش: "+money(c.getDouble(5));
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(8,8,8,8); row.setBackgroundResource(R.drawable.bg_card);
            row.addView(tv(s,16));
            Button del=btn("حذف کالا"); row.addView(del); content.addView(row);
            del.setOnClickListener(v->{db.getWritableDatabase().delete("products","id=?",new String[]{""+pid});showProducts();});
        } c.close();
    }

    ArrayList<KeyItem> products(){
        ArrayList<KeyItem>a=new ArrayList<>(); Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name FROM products ORDER BY name",null);
        while(c.moveToNext())a.add(new KeyItem(c.getLong(0),c.getString(1)));c.close();return a;
    }
    ArrayList<KeyItem> customers(){
        ArrayList<KeyItem>a=new ArrayList<>(); Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name FROM customers ORDER BY name",null);
        while(c.moveToNext())a.add(new KeyItem(c.getLong(0),c.getString(1)));c.close();return a;
    }
    Spinner spinner(ArrayList<KeyItem>a){
        Spinner s=new Spinner(this); s.setAdapter(new ArrayAdapter<KeyItem>(this,android.R.layout.simple_spinner_dropdown_item,a)); s.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return s;
    }

    void showCustomers(){
        base("مشتریان و حساب");
        EditText name=input("نام مشتری");EditText phone=input("شماره تماس");EditText addr=input("آدرس");EditText opening=input("مبلغ اولیه بدهی");
        content.addView(name);content.addView(phone);content.addView(addr);content.addView(opening);
        Button add=btn("➕ ثبت مشتری");content.addView(add);
        add.setOnClickListener(v->{SQLiteDatabase d=db.getWritableDatabase();android.content.ContentValues cv=new android.content.ContentValues();
            cv.put("name",name.getText().toString());cv.put("phone",phone.getText().toString());cv.put("address",addr.getText().toString());cv.put("opening",n(opening));d.insert("customers",null,cv);showCustomers();});
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name FROM customers ORDER BY id DESC",null);
        while(c.moveToNext()){
            long cid=c.getLong(0); String nm=c.getString(1);
            double debt=db.scalar("SELECT COALESCE((SELECT opening FROM customers WHERE id="+cid+"),0)+COALESCE((SELECT SUM(total-paid) FROM sales WHERE customer_id="+cid+"),0)-COALESCE((SELECT SUM(amount) FROM payments WHERE customer_id="+cid+"),0)");
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(8,8,8,8);row.setBackgroundResource(R.drawable.bg_card);
            row.addView(tv("👤 "+nm+"\nمانده حساب: "+money(debt)+" افغانی",17));
            Button pay=btn("💵 دریافت رسید پرداخت");row.addView(pay);content.addView(row);
            pay.setOnClickListener(v->payment(cid,nm,debt));
        }c.close();
    }
    void payment(long cid,String nm,double debt){
        final EditText amount=input("مبلغ پرداختی"); final EditText method=input("روش پرداخت (نقدی/بانک...)");
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.addView(amount);box.addView(method);
        new AlertDialog.Builder(this).setTitle("رسید پرداخت: "+nm).setView(box).setPositiveButton("ثبت رسید",(d,w)->{
            double a=n(amount); if(a<=0)return; SQLiteDatabase x=db.getWritableDatabase();android.content.ContentValues cv=new android.content.ContentValues();
            cv.put("customer_id",cid);cv.put("amount",a);cv.put("date",now());cv.put("method",method.getText().toString());x.insert("payments",null,cv);
            double nd=Math.max(0,debt-a); new AlertDialog.Builder(this).setTitle("رسید پرداخت").setMessage("مشتری: "+nm+"\nمبلغ پرداخت: "+money(a)+" افغانی\nمانده حساب: "+money(nd)+" افغانی\nتاریخ: "+now()).setPositiveButton("باشه",null).show();
            showCustomers();
        }).setNegativeButton("انصراف",null).show();
    }

    void showSales(){
        base("ثبت فروش");
        ArrayList<KeyItem> ps=products(), cs=customers();
        if(ps.size()==0){card("اول کالا را در بخش «کالا» ثبت کنید.");return;}
        if(cs.size()==0){card("اول مشتری را ثبت کنید. برای فروش نقدی می‌توانید مشتری «نقدی» بسازید.");return;}
        Spinner sp=spinner(ps), sc=spinner(cs); content.addView(tv("کالا",15));content.addView(sp);content.addView(tv("مشتری",15));content.addView(sc);
        EditText qty=input("مقدار فروش");EditText price=input("قیمت فروش هر واحد (خالی = قیمت کالا)");EditText paid=input("مبلغ دریافتی الان (برای قرضی کمتر از کل)");
        content.addView(qty);content.addView(price);content.addView(paid);
        Button add=btn("🧾 ثبت فروش و کم کردن از انبار");content.addView(add);
        add.setOnClickListener(v->{
            long pid=id(sp),cid=id(sc);double q=n(qty);if(q<=0)return;
            Cursor cc=db.getReadableDatabase().rawQuery("SELECT qty,buy,sell FROM products WHERE id="+pid,null);if(!cc.moveToFirst()){cc.close();return;}
            double stock=cc.getDouble(0), buy=cc.getDouble(1), sell=cc.getDouble(2);cc.close();
            if(q>stock){Toast.makeText(this,"موجودی کافی نیست",Toast.LENGTH_LONG).show();return;}
            double pr=n(price);if(pr<=0)pr=sell;double total=q*pr,cost=q*buy,pa=Math.min(n(paid),total);
            SQLiteDatabase d=db.getWritableDatabase();android.content.ContentValues sv=new android.content.ContentValues();
            sv.put("customer_id",cid);sv.put("product_id",pid);sv.put("qty",q);sv.put("price",pr);sv.put("total",total);sv.put("cost",cost);sv.put("paid",pa);sv.put("date",now());d.insert("sales",null,sv);
            android.content.ContentValues pv=new android.content.ContentValues();pv.put("qty",stock-q);d.update("products",pv,"id=?",new String[]{""+pid});
            Toast.makeText(this,"فروش ثبت شد؛ موجودی انبار کم شد.",Toast.LENGTH_LONG).show();showSales();
        });
    }

    void showPurchases(){
        base("ثبت خرید");
        ArrayList<KeyItem> ps=products();if(ps.size()==0){card("اول کالا را ثبت کنید.");return;}
        Spinner sp=spinner(ps);content.addView(tv("کالا",15));content.addView(sp);
        EditText qty=input("مقدار خرید");EditText buy=input("قیمت خرید هر واحد");content.addView(qty);content.addView(buy);
        Button add=btn("📦 ثبت خرید و اضافه کردن به انبار");content.addView(add);
        add.setOnClickListener(v->{long pid=id(sp);double q=n(qty),p=n(buy);if(q<=0||p<=0)return;
            SQLiteDatabase d=db.getWritableDatabase();Cursor c=d.rawQuery("SELECT qty FROM products WHERE id="+pid,null);c.moveToFirst();double stock=c.getDouble(0);c.close();
            android.content.ContentValues pv=new android.content.ContentValues();pv.put("qty",stock+q);pv.put("buy",p);d.update("products",pv,"id=?",new String[]{""+pid});
            android.content.ContentValues cv=new android.content.ContentValues();cv.put("product_id",pid);cv.put("qty",q);cv.put("buy",p);cv.put("total",q*p);cv.put("date",now());d.insert("purchases",null,cv);
            Toast.makeText(this,"خرید ثبت شد و موجودی اضافه شد.",Toast.LENGTH_LONG).show();showPurchases();
        });
    }

    void showReport(){
        base("گزارش سود و زیان");
        double sales=db.scalar("SELECT COALESCE(SUM(total),0) FROM sales"),cost=db.scalar("SELECT COALESCE(SUM(cost),0) FROM sales");
        double exp=db.scalar("SELECT COALESCE(SUM(amount),0) FROM expenses");
        card("فروش کل: "+money(sales)+" افغانی\nبهای جنس فروخته‌شده: "+money(cost)+" افغانی\nهزینه‌ها: "+money(exp)+" افغانی\nسود ناخالص: "+money(sales-cost)+" افغانی\nسود خالص: "+money(sales-cost-exp)+" افغانی");
    }
}
