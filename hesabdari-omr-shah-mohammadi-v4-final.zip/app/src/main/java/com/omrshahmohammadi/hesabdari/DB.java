package com.omrshahmohammadi.hesabdari;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DB extends SQLiteOpenHelper {
    public DB(Context c){ super(c,"hesabdari.db",null,2); }
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,unit TEXT,qty REAL,buy REAL,sell REAL)");
        d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,address TEXT,opening REAL)");
        d.execSQL("CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,qty REAL,buy REAL,total REAL,date TEXT)");
        d.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER,number TEXT,date TEXT,total REAL,paid REAL)");
        d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER,product_id INTEGER,qty REAL,price REAL,total REAL,cost REAL,paid REAL,date TEXT,invoice_id INTEGER)");
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER,amount REAL,date TEXT,method TEXT)");
        d.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,amount REAL,date TEXT)");
    }
    public void onUpgrade(SQLiteDatabase d,int oldV,int newV){
        if(oldV<2){
            try{ d.execSQL("ALTER TABLE sales ADD COLUMN invoice_id INTEGER"); }catch(Exception ignored){}
            d.execSQL("CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER,number TEXT,date TEXT,total REAL,paid REAL)");
        }
    }
    public double scalar(String sql){
        Cursor c=getReadableDatabase().rawQuery(sql,null); double v=0;
        if(c.moveToFirst()) v=c.getDouble(0); c.close(); return v;
    }
    public String text(String sql){
        Cursor c=getReadableDatabase().rawQuery(sql,null); String v="";
        if(c.moveToFirst()) v=c.getString(0); c.close(); return v;
    }
}
