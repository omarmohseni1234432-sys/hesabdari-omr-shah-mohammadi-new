package com.omrshahmohammadi.accounting;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

/** ابزارهای پیشرفته حسابداری. این صفحه روی همان accounting.db کار می‌کند. */
public class AdvancedActivity extends Activity {
    private SQLiteDatabase db;
    private LinearLayout body;
    private final int green=Color.rgb(22,131,75), dark=Color.rgb(24,53,42);

    @Override public void onCreate(Bundle b){super.onCreate(b); db=SQLiteDatabase.openOrCreateDatabase(getDatabasePath("accounting.db"),null); ensureTables(); shell(); dashboard();}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private void ensureTables(){
        db.execSQL("CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,amount REAL,date TEXT,method TEXT,note TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS stock_adjustments(id INTEGER PRIMARY KEY AUTOINCREMENT,product TEXT,old_qty REAL,new_qty REAL,diff REAL,date TEXT,note TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS sales_returns(id INTEGER PRIMARY KEY AUTOINCREMENT,invoiceNo TEXT,product TEXT,qty REAL,amount REAL,date TEXT,note TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS purchase_returns(id INTEGER PRIMARY KEY AUTOINCREMENT,product TEXT,qty REAL,amount REAL,supplier TEXT,date TEXT,note TEXT)");
    }
    private void shell(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(247,250,248)); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView head=tv("🛠 امکانات پیشرفته حسابداری",21,Color.WHITE,true); head.setGravity(Gravity.CENTER); head.setBackgroundColor(Color.rgb(20,117,83)); root.addView(head,new LinearLayout.LayoutParams(-1,dp(76)));
        ScrollView sc=new ScrollView(this); body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(14),dp(14),dp(14),dp(24)); body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); sc.addView(body); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(button("← برگشت به حسابداری",()->finish()),new LinearLayout.LayoutParams(-1,dp(68))); setContentView(root);
    }
    private TextView tv(String s,float size,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setPadding(dp(6),dp(8),dp(6),dp(8));if(bold)v.setTypeface(null,1);return v;}
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(18);e.setMinHeight(dp(60));e.setPadding(dp(14),dp(8),dp(14),dp(8));e.setBackgroundColor(Color.WHITE);return e;}
    private Button button(String s,final Runnable r){Button b=new Button(this);b.setText(s);b.setTextSize(16);b.setMinHeight(dp(58));b.setPadding(dp(8),dp(6),dp(8),dp(6));b.setOnClickListener(v->r.run());return b;}
    private void clear(String title){body.removeAllViews();TextView t=tv(title,24,dark,true);t.setGravity(Gravity.CENTER);body.addView(t);}
    private void card(String s){LinearLayout box=new LinearLayout(this);box.setPadding(dp(14),dp(10),dp(14),dp(10));box.setBackgroundColor(Color.WHITE);box.addView(tv(s,15,dark,false));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(10));body.addView(box,p);}
    private void dashboard(){clear("ابزارهای پیشرفته");double exp=scalar("SELECT COALESCE(SUM(amount),0) FROM expenses");double ret=scalar("SELECT COALESCE(SUM(amount),0) FROM sales_returns");double stock=scalar("SELECT COALESCE(SUM(qty*buy),0) FROM products");card("💰 هزینه‌های ثبت‌شده: "+money(exp)+"\n↩️ برگشت فروش: "+money(ret)+"\n📦 ارزش فعلی انبار: "+money(stock));
        body.addView(button("💸 ثبت هزینه جاری شرکت",this::addExpense));
        body.addView(button("📦 اصلاح دستی موجودی کالا",this::adjustStock));
        body.addView(button("↩️ برگشت از فروش",this::salesReturn));
        body.addView(button("↩️ برگشت به فروشنده",this::purchaseReturn));
        body.addView(button("📒 دفتر جریان نقدی",this::cashBook));
        body.addView(button("🔴 گزارش بدهکاران مشتری",this::debtorReport));
        body.addView(button("📦 گزارش گردش انبار",this::stockReport));
        body.addView(button("📤 خروجی متنی گزارش‌ها",this::exportSummary));
    }
    private String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    private double parse(String s){try{return Double.parseDouble(s.replace(",",""));}catch(Exception e){return 0;}}
    private double scalar(String q){Cursor c=db.rawQuery(q,null);try{return c.moveToFirst()?c.getDouble(0):0;}finally{c.close();}}
    private String money(double x){return String.format(Locale.US,"%,.0f افغانی",x);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private LinearLayout box(){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(dp(18),dp(8),dp(18),dp(4));return b;}

    private void addExpense(){LinearLayout b=box();EditText title=field("عنوان هزینه"),amount=field("مبلغ"),date=field("تاریخ"),note=field("یادداشت");amount.setInputType(2);date.setText(today());Spinner method=new Spinner(this);method.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,Arrays.asList("نقدی","بانکی","کارت","سایر")));b.addView(title);b.addView(amount);b.addView(date);b.addView(method);b.addView(note);new AlertDialog.Builder(this).setTitle("💸 ثبت هزینه").setView(b).setPositiveButton("ثبت",(d,w)->{double a=parse(amount.getText().toString());if(a<=0){toast("مبلغ را وارد کنید");return;}db.execSQL("INSERT INTO expenses(title,amount,date,method,note) VALUES(?,?,?,?,?)",new Object[]{title.getText().toString(),a,date.getText().toString(),method.getSelectedItem().toString(),note.getText().toString()});toast("هزینه ثبت شد");dashboard();}).setNegativeButton("لغو",null).show();}

    private void adjustStock(){ArrayList<String> names=new ArrayList<>();Cursor c=db.rawQuery("SELECT name FROM products ORDER BY name",null);while(c.moveToNext())names.add(c.getString(0));c.close();if(names.isEmpty()){toast("کالایی ثبت نشده است");return;}LinearLayout b=box();Spinner p=new Spinner(this);p.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));EditText q=field("موجودی جدید"),note=field("دلیل اصلاح");q.setInputType(2);b.addView(p);b.addView(q);b.addView(note);new AlertDialog.Builder(this).setTitle("📦 اصلاح موجودی").setView(b).setPositiveButton("ذخیره",(d,w)->{String name=p.getSelectedItem().toString();Cursor x=db.rawQuery("SELECT qty FROM products WHERE name=?",new String[]{name});double old=0;if(x.moveToFirst())old=x.getDouble(0);x.close();double neu=parse(q.getText().toString());if(neu<0){toast("موجودی نمی‌تواند منفی باشد");return;}db.execSQL("UPDATE products SET qty=? WHERE name=?",new Object[]{neu,name});db.execSQL("INSERT INTO stock_adjustments(product,old_qty,new_qty,diff,date,note) VALUES(?,?,?,?,?,?)",new Object[]{name,old,neu,neu-old,today(),note.getText().toString()});toast("موجودی اصلاح شد");dashboard();}).setNegativeButton("لغو",null).show();}

    private void salesReturn(){ArrayList<String> products=new ArrayList<>();Cursor c=db.rawQuery("SELECT name FROM products ORDER BY name",null);while(c.moveToNext())products.add(c.getString(0));c.close();if(products.isEmpty()){toast("کالایی ثبت نشده است");return;}LinearLayout b=box();EditText inv=field("شماره فاکتور (اختیاری)"),qty=field("تعداد برگشتی"),amount=field("مبلغ برگشتی"),note=field("یادداشت");qty.setInputType(2);amount.setInputType(2);Spinner p=new Spinner(this);p.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,products));b.addView(p);b.addView(inv);b.addView(qty);b.addView(amount);b.addView(note);new AlertDialog.Builder(this).setTitle("↩️ برگشت از فروش").setView(b).setPositiveButton("ثبت",(d,w)->{double q=parse(qty.getText().toString()),a=parse(amount.getText().toString());if(q<=0){toast("تعداد برگشتی را وارد کنید");return;}String name=p.getSelectedItem().toString();db.execSQL("UPDATE products SET qty=qty+? WHERE name=?",new Object[]{q,name});db.execSQL("INSERT INTO sales_returns(invoiceNo,product,qty,amount,date,note) VALUES(?,?,?,?,?,?)",new Object[]{inv.getText().toString(),name,q,a,today(),note.getText().toString()});toast("برگشت فروش ثبت و موجودی افزایش یافت");dashboard();}).setNegativeButton("لغو",null).show();}

    private void purchaseReturn(){ArrayList<String> products=new ArrayList<>();Cursor c=db.rawQuery("SELECT name FROM products ORDER BY name",null);while(c.moveToNext())products.add(c.getString(0));c.close();if(products.isEmpty()){toast("کالایی ثبت نشده است");return;}LinearLayout b=box();EditText qty=field("تعداد برگشتی"),amount=field("مبلغ برگشت"),supplier=field("نام فروشنده"),note=field("یادداشت");qty.setInputType(2);amount.setInputType(2);Spinner p=new Spinner(this);p.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,products));b.addView(p);b.addView(qty);b.addView(amount);b.addView(supplier);b.addView(note);new AlertDialog.Builder(this).setTitle("↩️ برگشت به فروشنده").setView(b).setPositiveButton("ثبت",(d,w)->{String name=p.getSelectedItem().toString();double q=parse(qty.getText().toString()),a=parse(amount.getText().toString());if(q<=0){toast("تعداد برگشتی را وارد کنید");return;}Cursor x=db.rawQuery("SELECT qty FROM products WHERE name=?",new String[]{name});double old=0;if(x.moveToFirst())old=x.getDouble(0);x.close();if(q>old){toast("موجودی کافی نیست");return;}db.execSQL("UPDATE products SET qty=qty-? WHERE name=?",new Object[]{q,name});db.execSQL("INSERT INTO purchase_returns(product,qty,amount,supplier,date,note) VALUES(?,?,?,?,?,?)",new Object[]{name,q,a,supplier.getText().toString(),today(),note.getText().toString()});toast("برگشت خرید ثبت شد");dashboard();}).setNegativeButton("لغو",null).show();}

    private void cashBook(){clear("دفتر جریان نقدی");double sales=scalar("SELECT COALESCE(SUM(paid),0) FROM invoices"),payments=scalar("SELECT COALESCE(SUM(amount),0) FROM payments"),purchases=scalar("SELECT COALESCE(SUM(paid),0) FROM purchases"),supplierPay=scalar("SELECT COALESCE(SUM(amount),0) FROM supplier_payments"),expenses=scalar("SELECT COALESCE(SUM(amount),0) FROM expenses");card("ورودی فروش: "+money(sales)+"\nدریافت از مشتری: "+money(payments)+"\nخرید پرداخت‌شده: "+money(purchases)+"\nپرداخت به فروشنده: "+money(supplierPay)+"\nهزینه‌ها: "+money(expenses)+"\n\nمانده جریان ثبت‌شده: "+money(sales+payments-purchases-supplierPay-expenses));body.addView(button("← برگشت",this::dashboard));}

    private void debtorReport(){clear("گزارش بدهکاران");Cursor c=db.rawQuery("SELECT name,initialDebt FROM customers ORDER BY name",null);while(c.moveToNext()){String n=c.getString(0);double bal=c.getDouble(1)+scalarParam("SELECT COALESCE(SUM(net_total),0) FROM invoices WHERE customer=?",n)-scalarParam("SELECT COALESCE(SUM(paid),0) FROM invoices WHERE customer=?",n)-scalarParam("SELECT COALESCE(SUM(amount),0) FROM payments WHERE customer=?",n);if(bal>0)card("👤 "+n+"\nمانده بدهی: "+money(bal));}c.close();body.addView(button("← برگشت",this::dashboard));}
    private double scalarParam(String q,String p){Cursor c=db.rawQuery(q,new String[]{p});try{return c.moveToFirst()?c.getDouble(0):0;}finally{c.close();}}

    private void stockReport(){clear("گردش و وضعیت انبار");Cursor c=db.rawQuery("SELECT name,unit,qty,buy,sell,minQty FROM products ORDER BY name",null);while(c.moveToNext())card("📦 "+c.getString(0)+"\nموجودی: "+c.getDouble(2)+" "+c.getString(1)+" | خرید: "+money(c.getDouble(3))+" | فروش: "+money(c.getDouble(4))+"\nحد هشدار: "+c.getDouble(5));c.close();body.addView(button("← برگشت",this::dashboard));}

    private void exportSummary(){StringBuilder s=new StringBuilder();s.append("گزارش حسابداری شرکت زراعتی عمر شاه محمدی\nتاریخ: ").append(today()).append("\n\n");s.append("فروش کل: ").append(money(scalar("SELECT COALESCE(SUM(net_total),0) FROM invoices"))).append("\n");s.append("خرید کل: ").append(money(scalar("SELECT COALESCE(SUM(total),0) FROM purchases"))).append("\n");s.append("هزینه‌ها: ").append(money(scalar("SELECT COALESCE(SUM(amount),0) FROM expenses"))).append("\n");s.append("ارزش انبار: ").append(money(scalar("SELECT COALESCE(SUM(qty*buy),0) FROM products"))).append("\n");Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"گزارش حسابداری");i.putExtra(Intent.EXTRA_TEXT,s.toString());startActivity(Intent.createChooser(i,"ارسال گزارش"));}
}
