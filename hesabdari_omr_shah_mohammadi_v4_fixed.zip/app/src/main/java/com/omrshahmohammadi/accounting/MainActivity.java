package com.omrshahmohammadi.accounting;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db;
    LinearLayout content;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        home();
    }

    int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    TextView text(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(Color.DKGRAY);
        t.setGravity(android.view.Gravity.RIGHT | android.view.Gravity.CENTER_VERTICAL);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        return t;
    }

    EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(16);
        e.setGravity(android.view.Gravity.RIGHT | android.view.Gravity.CENTER_VERTICAL);
        e.setTextDirection(View.TEXT_DIRECTION_RTL);
        e.setPadding(dp(12), dp(4), dp(12), dp(4));
        e.setSingleLine(true);
        return e;
    }

    Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(15);
        b.setGravity(android.view.Gravity.CENTER);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(6), dp(2), dp(6), dp(2));
        return b;
    }

    TextView navButton(String s) {
        TextView b = new TextView(this);
        b.setText(s);
        b.setTextSize(13);
        b.setTextColor(Color.DKGRAY);
        b.setGravity(android.view.Gravity.CENTER);
        b.setBackgroundColor(Color.rgb(238, 238, 238));
        b.setPadding(dp(2), 0, dp(2), 0);
        b.setTextDirection(View.TEXT_DIRECTION_RTL);
        return b;
    }

    void page(String title) {
        LinearLayout all = new LinearLayout(this);
        all.setOrientation(LinearLayout.VERTICAL);
        all.setBackgroundColor(Color.WHITE);
        all.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView h = new TextView(this);
        h.setText(title);
        h.setTextSize(21);
        h.setTextColor(Color.WHITE);
        h.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        h.setGravity(android.view.Gravity.RIGHT | android.view.Gravity.CENTER_VERTICAL);
        h.setTextDirection(View.TEXT_DIRECTION_RTL);
        h.setPadding(dp(16), 0, dp(16), 0);
        h.setBackgroundColor(Color.rgb(21,101,192));
        all.addView(h, new LinearLayout.LayoutParams(-1, dp(56)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(android.view.Gravity.RIGHT);
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        content.setPadding(dp(12), dp(10), dp(12), dp(12));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        all.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(android.view.Gravity.CENTER);
        nav.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        nav.setPadding(dp(4), dp(4), dp(4), dp(4));
        nav.setBackgroundColor(Color.rgb(245,245,245));

        String[] names={"خانه","فروش","کالا","مشتری","خرید"};
        for(String n:names){
            TextView b=navButton(n);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(50), 1);
            lp.setMargins(dp(2), 0, dp(2), 0);
            nav.addView(b, lp);
            if(n.equals("خانه")) b.setOnClickListener(v->home());
            if(n.equals("فروش")) b.setOnClickListener(v->sales());
            if(n.equals("کالا")) b.setOnClickListener(v->products());
            if(n.equals("مشتری")) b.setOnClickListener(v->customers());
            if(n.equals("خرید")) b.setOnClickListener(v->purchases());
        }
        all.addView(nav, new LinearLayout.LayoutParams(-1, dp(58)));
        setContentView(all);
    }

    void addField(EditText e) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.setMargins(0, dp(3), 0, dp(3));
        content.addView(e, lp);
    }

    void addButton(Button b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.setMargins(0, dp(6), 0, dp(8));
        content.addView(b, lp);
    }

    String fmt(double x){return String.format(Locale.US,"%.0f",x);}
    String date(){return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());}

    void home(){
        page("حسابداری عمر شاه محمدی");
        content.addView(text("داشبورد",25));
        Cursor c=db.rawQuery("SELECT COALESCE(SUM(total),0) FROM sales",null); c.moveToFirst();
        double s=c.getDouble(0); c.close();
        c=db.rawQuery("SELECT COALESCE(SUM(total),0) FROM purchases",null); c.moveToFirst();
        double p=c.getDouble(0); c.close();
        content.addView(text("فروش کل: "+fmt(s)+" افغانی",19));
        content.addView(text("خرید کل: "+fmt(p)+" افغانی",19));
        content.addView(text("سود ناخالص: "+fmt(s-p)+" افغانی",20));
        Button r=button("گزارش سود و زیان"); r.setOnClickListener(v->report()); addButton(r);
    }

    void products(){
        page("کالا و موجودی");
        EditText n=field("نام کالا"); EditText u=field("واحد"); EditText q=field("موجودی"); EditText bp=field("قیمت خرید");
        Button add=button("ثبت کالا");
        addField(n); addField(u); addField(q); addField(bp); addButton(add);
        add.setOnClickListener(v->{
            try{
                db.execSQL("INSERT INTO products(name,unit,qty,buy_price) VALUES(?,?,?,?)",
                    new Object[]{n.getText().toString(),u.getText().toString(),Double.parseDouble(q.getText().toString()),Double.parseDouble(bp.getText().toString())});
                Toast.makeText(this,"کالا ثبت شد",Toast.LENGTH_SHORT).show(); products();
            }catch(Exception e){Toast.makeText(this,"اطلاعات را کامل وارد کنید",Toast.LENGTH_SHORT).show();}
        });
        content.addView(text("موجودی فعلی",20));
        Cursor c=db.rawQuery("SELECT name,unit,qty,buy_price FROM products ORDER BY id DESC",null);
        while(c.moveToNext()) content.addView(text(c.getString(0)+" | "+fmt(c.getDouble(2))+" "+c.getString(1)+" | "+fmt(c.getDouble(3))+" افغانی",16));
        c.close();
    }

    void customers(){
        page("مشتریان");
        EditText n=field("نام مشتری"); EditText ph=field("شماره تلفن"); EditText ad=field("آدرس"); EditText bal=field("بدهی اولیه");
        Button add=button("ثبت مشتری");
        addField(n); addField(ph); addField(ad); addField(bal); addButton(add);
        add.setOnClickListener(v->{
            try{
                double x=bal.getText().length()==0?0:Double.parseDouble(bal.getText().toString());
                db.execSQL("INSERT INTO customers(name,phone,address,balance) VALUES(?,?,?,?)",
                    new Object[]{n.getText().toString(),ph.getText().toString(),ad.getText().toString(),x});
                Toast.makeText(this,"مشتری ثبت شد",Toast.LENGTH_SHORT).show(); customers();
            }catch(Exception e){Toast.makeText(this,"اطلاعات را کامل وارد کنید",Toast.LENGTH_SHORT).show();}
        });
        content.addView(text("حساب مشتریان",20));
        Cursor c=db.rawQuery("SELECT name,phone,balance FROM customers ORDER BY id DESC",null);
        while(c.moveToNext()) content.addView(text(c.getString(0)+" | "+c.getString(1)+" | مانده "+fmt(c.getDouble(2))+" افغانی",16));
        c.close();
    }

    void sales(){
        page("فروش نقدی / نسیه");
        EditText cu=field("نام مشتری (نقدی یا نام مشتری)"); EditText pr=field("نام کالا");
        EditText q=field("مقدار"); EditText price=field("قیمت فروش واحد"); EditText paid=field("دریافت");
        Button add=button("ثبت فروش");
        addField(cu); addField(pr); addField(q); addField(price); addField(paid); addButton(add);
        add.setOnClickListener(v->{
            try{
                double qty=Double.parseDouble(q.getText().toString());
                double unit=Double.parseDouble(price.getText().toString());
                double pay=Double.parseDouble(paid.getText().toString());
                double total=qty*unit; String customer=cu.getText().toString();
                db.execSQL("INSERT INTO sales(customer,product,qty,price,total,paid,date) VALUES(?,?,?,?,?,?,?)",
                    new Object[]{customer,pr.getText().toString(),qty,unit,total,pay,date()});
                db.execSQL("UPDATE products SET qty=qty-? WHERE name=?",new Object[]{qty,pr.getText().toString()});
                if(!customer.equals("نقدی")) db.execSQL("UPDATE customers SET balance=balance+? WHERE name=?",new Object[]{total-pay,customer});
                Toast.makeText(this,"فروش ثبت شد",Toast.LENGTH_SHORT).show(); sales();
            }catch(Exception e){Toast.makeText(this,"اطلاعات فروش را درست وارد کنید",Toast.LENGTH_SHORT).show();}
        });
        content.addView(text("آخرین فروش‌ها",20));
        Cursor c=db.rawQuery("SELECT customer,product,total,paid,date FROM sales ORDER BY id DESC LIMIT 20",null);
        while(c.moveToNext()) content.addView(text(c.getString(0)+" | "+c.getString(1)+" | "+fmt(c.getDouble(2))+" | دریافت "+fmt(c.getDouble(3)),15));
        c.close();
    }

    void purchases(){
        page("خرید از تأمین‌کننده");
        EditText su=field("نام تأمین‌کننده"); EditText pr=field("نام کالا");
        EditText q=field("مقدار"); EditText price=field("قیمت خرید واحد"); EditText paid=field("پرداخت");
        Button add=button("ثبت خرید");
        addField(su); addField(pr); addField(q); addField(price); addField(paid); addButton(add);
        add.setOnClickListener(v->{
            try{
                double qty=Double.parseDouble(q.getText().toString());
                double unit=Double.parseDouble(price.getText().toString());
                double pay=Double.parseDouble(paid.getText().toString());
                double total=qty*unit;
                db.execSQL("INSERT INTO purchases(supplier,product,qty,price,total,paid,date) VALUES(?,?,?,?,?,?,?)",
                    new Object[]{su.getText().toString(),pr.getText().toString(),qty,unit,total,pay,date()});
                db.execSQL("UPDATE products SET qty=qty+? WHERE name=?",new Object[]{qty,pr.getText().toString()});
                Toast.makeText(this,"خرید ثبت شد",Toast.LENGTH_SHORT).show(); purchases();
            }catch(Exception e){Toast.makeText(this,"اطلاعات خرید را درست وارد کنید",Toast.LENGTH_SHORT).show();}
        });
        content.addView(text("آخرین خریدها",20));
        Cursor c=db.rawQuery("SELECT supplier,product,total,paid,date FROM purchases ORDER BY id DESC LIMIT 20",null);
        while(c.moveToNext()) content.addView(text(c.getString(0)+" | "+c.getString(1)+" | "+fmt(c.getDouble(2))+" | پرداخت "+fmt(c.getDouble(3)),15));
        c.close();
    }

    void report(){
        page("گزارش سود و زیان");
        Cursor c=db.rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(paid),0) FROM sales",null); c.moveToFirst();
        double s=c.getDouble(0), sp=c.getDouble(1); c.close();
        c=db.rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(paid),0) FROM purchases",null); c.moveToFirst();
        double p=c.getDouble(0), pp=c.getDouble(1); c.close();
        content.addView(text("فروش کل: "+fmt(s)+" افغانی",20));
        content.addView(text("خرید کل: "+fmt(p)+" افغانی",20));
        content.addView(text("سود ناخالص: "+fmt(s-p)+" افغانی",22));
        content.addView(text("مطالبات مشتریان: "+fmt(s-sp)+" افغانی",18));
        content.addView(text("بدهی به تأمین‌کنندگان: "+fmt(p-pp)+" افغانی",18));
    }

    static class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"accounting.db",null,1);}
        Cursor rawQuery(String sql, String[] args){ return getReadableDatabase().rawQuery(sql, args); }
        void execSQL(String sql, Object[] bindArgs){ getWritableDatabase().execSQL(sql, bindArgs); }
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,unit TEXT,qty REAL,buy_price REAL)");
            d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,address TEXT,balance REAL)");
            d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,customer TEXT,product TEXT,qty REAL,price REAL,total REAL,paid REAL,date TEXT)");
            d.execSQL("CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,supplier TEXT,product TEXT,qty REAL,price REAL,total REAL,paid REAL,date TEXT)");
        }
        public void onUpgrade(SQLiteDatabase d,int oldV,int newV){}
    }
}
