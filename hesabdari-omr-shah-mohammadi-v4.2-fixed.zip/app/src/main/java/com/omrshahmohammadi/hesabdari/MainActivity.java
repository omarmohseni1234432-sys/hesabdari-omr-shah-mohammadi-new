package com.omrshahmohammadi.hesabdari;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout root, content; TextView title;
    int BLUE=Color.rgb(25,118,210), DARK=Color.rgb(35,45,55), LIGHT=Color.rgb(245,247,250);
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b); getWindow().setStatusBarColor(BLUE);
        db=new DB(this); showHome();
    }
    TextView tv(String s,int size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(DARK);
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); t.setPadding(16,10,16,10);
        t.setTypeface(Typeface.DEFAULT); t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return t;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(15); b.setAllCaps(false);
        b.setTextColor(DARK); b.setBackgroundColor(Color.WHITE); b.setPadding(8,4,8,4);
        b.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return b;
    }
    EditText input(String hint){
        EditText e=new EditText(this); e.setHint(hint); e.setTextSize(16); e.setSingleLine(true);
        e.setPadding(14,4,14,4); e.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return e;
    }
    void base(String name){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(LIGHT);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        title=tv(name,22); title.setTextColor(Color.WHITE); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        title.setGravity(Gravity.CENTER); title.setBackgroundColor(BLUE);
        title.setPadding(dp(12),0,dp(12),0); root.addView(title,new LinearLayout.LayoutParams(-1,dp(64)));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(12),dp(12),dp(12),dp(8));
        TextView wm=tv("🌿  حسابداری شرکت زراعتی عمر شاه محمدی  🌿",13);
        wm.setTextColor(Color.argb(45,20,130,70)); wm.setGravity(Gravity.CENTER); content.addView(wm,new LinearLayout.LayoutParams(-1,dp(30)));
        ScrollView sc=new ScrollView(this); sc.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); sc.addView(content);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(Color.WHITE);
        String[] ns={"خانه","فروش","کالا","مشتری","خرید"};
        for(String n:ns){ Button b=btn(n); nav.addView(b,new LinearLayout.LayoutParams(0,58,1));
            b.setOnClickListener(v->{ if(n.equals("خانه"))showHome(); else if(n.equals("فروش"))showSales(); else if(n.equals("کالا"))showProducts(); else if(n.equals("مشتری"))showCustomers(); else showPurchases();});
        }
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(62))); setContentView(root);
    }
    void add(TextView v){ content.addView(v,new LinearLayout.LayoutParams(-1,-2)); }
    void card(String s){
        TextView v=tv(s,17); v.setBackgroundResource(com.omrshahmohammadi.hesabdari.R.drawable.bg_card);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,7,0,7); content.addView(v,p);
    }
    String now(){return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());}
    double n(EditText e){try{return Double.parseDouble(e.getText().toString().trim());}catch(Exception x){return 0;}}
    long id(Spinner s){return ((KeyItem)s.getSelectedItem()).id;}
    static class KeyItem { long id; String name; KeyItem(long i,String n){id=i;name=n;} public String toString(){return name;} }
    static class SaleLine {
        long pid; String name,unit; double qty,price,buy;
        SaleLine(long p,String n,String u,double q,double pr,double b){pid=p;name=n;unit=u;qty=q;price=pr;buy=b;}
        double total(){return qty*price;}
    }
    ArrayList<SaleLine> cart=new ArrayList<>();


    void showHome(){
        base("حسابداری عمر شاه محمدی");
        add(tv("داشبورد",25));
        double sales=db.scalar("SELECT COALESCE(SUM(total),0) FROM sales");
        double cost=db.scalar("SELECT COALESCE(SUM(cost),0) FROM sales");
        double expenses=db.scalar("SELECT COALESCE(SUM(amount),0) FROM expenses");
        double purchases=db.scalar("SELECT COALESCE(SUM(total),0) FROM purchases");
        double profit=sales-cost-expenses;
        card("💰 فروش کل\n"+money(sales)+" افغانی");
        card("📦 خرید ثبت‌شده\n"+money(purchases)+" افغانی");
        card("📈 سود خالص\n"+money(profit)+" افغانی\n(فروش − بهای جنس فروخته‌شده − هزینه‌ها)");
        card("🏦 بهای جنس فروخته‌شده\n"+money(cost)+" افغانی");
        double debt=db.scalar("SELECT COALESCE(SUM(opening),0)+COALESCE((SELECT SUM(total-paid) FROM sales),0)-COALESCE((SELECT SUM(amount) FROM payments),0) FROM customers");
        card("👥 مانده بدهی مشتریان\n"+money(debt)+" افغانی");
        Button r=btn("📊 گزارش کامل سود و زیان"); r.setOnClickListener(v->showReport()); content.addView(r);
        Button b=btn("☁️ پشتیبان‌گیری / ارسال فایل حسابداری"); b.setOnClickListener(v->backupAndShare()); content.addView(b);
        Button tx=btn("📒 دفتر تراکنش‌ها"); tx.setOnClickListener(v->showAllTransactions()); content.addView(tx);
    }
    String money(double x){return String.format(Locale.US,"%,.0f",x);}

    void showProducts(){
        base("کالا و موجودی");
        EditText name=input("نام کالا"); EditText unit=input("واحد (بوتل، کیلو، لیتر...)");
        EditText qty=input("موجودی اولیه"); EditText buy=input("قیمت خرید هر واحد"); EditText sell=input("قیمت فروش هر واحد");
        content.addView(name); content.addView(unit); content.addView(qty); content.addView(buy); content.addView(sell);
        Button add=btn("➕ ثبت کالا"); content.addView(add);
        add.setOnClickListener(v->{ if(name.getText().toString().trim().isEmpty())return;
            SQLiteDatabase d=db.getWritableDatabase(); android.content.ContentValues cv=new android.content.ContentValues();
            cv.put("name",name.getText().toString());cv.put("unit",unit.getText().toString());cv.put("qty",n(qty));cv.put("buy",n(buy));cv.put("sell",n(sell));d.insert("products",null,cv);
            Toast.makeText(this,"کالا ثبت شد",Toast.LENGTH_SHORT).show(); showProducts();
        });
        add(tv("موجودی فعلی",20));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,unit,qty,buy,sell FROM products ORDER BY id DESC",null);
        while(c.moveToNext()){
            long pid=c.getLong(0); String s=c.getString(1)+" | "+c.getString(2)+"\nموجودی: "+money(c.getDouble(3))+
                    "\nخرید: "+money(c.getDouble(4))+" | فروش: "+money(c.getDouble(5));
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(8,8,8,8); row.setBackgroundResource(R.drawable.bg_card);
            row.addView(tv(s,16));
            Button del=btn("حذف کالا"); row.addView(del); content.addView(row);
            del.setOnClickListener(v->{db.getWritableDatabase().delete("products","id=?",new String[]{""+pid});showProducts();});
        } c.close();
    }

    ArrayList<KeyItem> products(){
        ArrayList<KeyItem>a=new ArrayList<>(); Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name FROM products ORDER BY name",null);
        while(c.moveToNext())a.add(new KeyItem(c.getLong(0),c.getString(1)));c.close();return a;
    }
    ArrayList<KeyItem> customers(){
        ArrayList<KeyItem>a=new ArrayList<>(); Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name FROM customers ORDER BY name",null);
        while(c.moveToNext())a.add(new KeyItem(c.getLong(0),c.getString(1)));c.close();return a;
    }
    Spinner spinner(ArrayList<KeyItem>a){
        Spinner s=new Spinner(this); s.setAdapter(new ArrayAdapter<KeyItem>(this,android.R.layout.simple_spinner_dropdown_item,a)); s.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return s;
    }

    void showCustomers(){
        base("مشتریان و حساب");
        EditText name=input("نام مشتری");EditText phone=input("شماره تماس");EditText addr=input("آدرس");EditText opening=input("مبلغ اولیه بدهی");
        content.addView(name);content.addView(phone);content.addView(addr);content.addView(opening);
        Button add=btn("➕ ثبت مشتری");content.addView(add);
        add.setOnClickListener(v->{SQLiteDatabase d=db.getWritableDatabase();android.content.ContentValues cv=new android.content.ContentValues();
            cv.put("name",name.getText().toString());cv.put("phone",phone.getText().toString());cv.put("address",addr.getText().toString());cv.put("opening",n(opening));d.insert("customers",null,cv);showCustomers();});
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name FROM customers ORDER BY id DESC",null);
        while(c.moveToNext()){
            long cid=c.getLong(0); String nm=c.getString(1);
            double debt=db.scalar("SELECT COALESCE((SELECT opening FROM customers WHERE id="+cid+"),0)+COALESCE((SELECT SUM(total-paid) FROM sales WHERE customer_id="+cid+"),0)-COALESCE((SELECT SUM(amount) FROM payments WHERE customer_id="+cid+"),0)");
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(8,8,8,8);row.setBackgroundResource(R.drawable.bg_card);
            row.addView(tv("👤 "+nm+"\nمانده حساب: "+money(debt)+" افغانی",17));
            Button hist=btn("📒 گردش حساب مشتری"); row.addView(hist);
            Button pay=btn("💵 دریافت رسید پرداخت");row.addView(pay);content.addView(row);
            hist.setOnClickListener(v->showCustomerHistory(cid,nm));
            pay.setOnClickListener(v->payment(cid,nm,debt));
        }c.close();
    }
    void payment(long cid,String nm,double debt){
        final EditText amount=input("مبلغ پرداختی"); final EditText method=input("روش پرداخت (نقدی/بانک...)");
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.addView(amount);box.addView(method);
        new AlertDialog.Builder(this).setTitle("رسید پرداخت: "+nm).setView(box).setPositiveButton("ثبت رسید",(d,w)->{
            double a=n(amount); if(a<=0)return; SQLiteDatabase x=db.getWritableDatabase();android.content.ContentValues cv=new android.content.ContentValues();
            cv.put("customer_id",cid);cv.put("amount",a);cv.put("date",now());cv.put("method",method.getText().toString());x.insert("payments",null,cv);
            double nd=Math.max(0,debt-a); new AlertDialog.Builder(this).setTitle("رسید پرداخت").setMessage("مشتری: "+nm+"\nمبلغ پرداخت: "+money(a)+" افغانی\nمانده حساب: "+money(nd)+" افغانی\nتاریخ: "+now()).setPositiveButton("باشه",null).show();
            showCustomers();
        }).setNegativeButton("انصراف",null).show();
    }


    void showCustomerHistory(long cid,String nm){
        base("گردش حساب: "+nm);
        double opening=db.scalar("SELECT COALESCE(opening,0) FROM customers WHERE id="+cid);
        double sales=db.scalar("SELECT COALESCE(SUM(total),0) FROM sales WHERE customer_id="+cid);
        double paidSales=db.scalar("SELECT COALESCE(SUM(paid),0) FROM sales WHERE customer_id="+cid);
        double payments=db.scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE customer_id="+cid);
        card("مانده فعلی: "+money(opening+sales-paidSales-payments)+" افغانی");
        Cursor s=db.getReadableDatabase().rawQuery("SELECT date,total,paid FROM sales WHERE customer_id="+cid+" ORDER BY id DESC",null);
        while(s.moveToNext()) card("🧾 فروش | "+s.getString(0)+"\nکل: "+money(s.getDouble(1))+" افغانی | پرداخت: "+money(s.getDouble(2))+" افغانی");
        s.close();
        Cursor q=db.getReadableDatabase().rawQuery("SELECT date,amount,method FROM payments WHERE customer_id="+cid+" ORDER BY id DESC",null);
        while(q.moveToNext()) card("💵 رسید پرداخت | "+q.getString(0)+"\nمبلغ: "+money(q.getDouble(1))+" افغانی | روش: "+q.getString(2));
        q.close();
        if(opening!=0) card("📌 بدهی اولیه: "+money(opening)+" افغانی");
    }
    void showAllTransactions(){
        base("دفتر تراکنش‌ها");
        Cursor c=db.getReadableDatabase().rawQuery("SELECT s.date,c.name,p.name,s.total,s.paid FROM sales s LEFT JOIN customers c ON c.id=s.customer_id LEFT JOIN products p ON p.id=s.product_id ORDER BY s.id DESC",null);
        while(c.moveToNext()) card("🧾 فروش | "+c.getString(0)+"\nمشتری: "+c.getString(1)+"\nکالا: "+c.getString(2)+"\nکل: "+money(c.getDouble(3))+" | پرداخت: "+money(c.getDouble(4)));
        c.close();
        Cursor q=db.getReadableDatabase().rawQuery("SELECT p.date,c.name,p.amount,p.method FROM payments p LEFT JOIN customers c ON c.id=p.customer_id ORDER BY p.id DESC",null);
        while(q.moveToNext()) card("💵 رسید پرداخت | "+q.getString(0)+"\nمشتری: "+q.getString(1)+"\nمبلغ: "+money(q.getDouble(2))+" افغانی | "+q.getString(3));
        q.close();
    }
    void backupAndShare(){
        try{
            java.io.File dir=getExternalFilesDir(android.os.Environment.DIRECTORY_DOCUMENTS);
            if(dir==null) dir=getFilesDir();
            java.io.File out=new java.io.File(dir,"hesabdari-backup-"+new java.text.SimpleDateFormat("yyyyMMdd-HHmm",java.util.Locale.US).format(new java.util.Date())+".db");
            java.io.FileInputStream in=new java.io.FileInputStream(getDatabasePath("hesabdari.db"));
            java.io.FileOutputStream fo=new java.io.FileOutputStream(out);
            byte[] buf=new byte[8192]; int len; while((len=in.read(buf))>0) fo.write(buf,0,len);
            in.close(); fo.close();
            android.content.Intent share=new android.content.Intent(android.content.Intent.ACTION_SEND);
            share.setType("application/octet-stream");
            share.putExtra(android.content.Intent.EXTRA_STREAM,android.net.Uri.parse(out.toURI().toString()));
            share.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(share,"ذخیره یا ارسال پشتیبان"));
        }catch(Exception e){ Toast.makeText(this,"پشتیبان‌گیری انجام نشد",Toast.LENGTH_LONG).show(); }
    }


    void showSales(){
        base("فاکتور فروش");
        ArrayList<KeyItem> ps=products(), cs=customers();
        if(ps.size()==0){card("اول کالا را در بخش «کالا» ثبت کنید.");return;}
        if(cs.size()==0){card("اول مشتری را ثبت کنید. برای فروش نقدی می‌توانید مشتری «نقدی» بسازید.");return;}

        add(tv("فاکتور چندکالایی",21));
        Spinner sc=spinner(cs); add(tv("مشتری",15)); content.addView(sc);

        Spinner sp=spinner(ps); add(tv("انتخاب کالا",15)); content.addView(sp);
        EditText qty=input("تعداد / مقدار"); EditText price=input("قیمت فروش هر واحد (خالی = قیمت کالا)");
        content.addView(qty); content.addView(price);
        Button addLine=btn("➕ افزودن کالا به فاکتور"); content.addView(addLine);

        LinearLayout cartBox=new LinearLayout(this); cartBox.setOrientation(LinearLayout.VERTICAL);
        cartBox.setBackgroundResource(R.drawable.bg_card); content.addView(cartBox);
        TextView cartTitle=tv("اقلام فاکتور",18); cartBox.addView(cartTitle);

        final Runnable[] render=new Runnable[1];
        render[0]=()->{
            while(cartBox.getChildCount()>1) cartBox.removeViewAt(1);
            double total=0;
            for(int i=0;i<cart.size();i++){
                SaleLine l=cart.get(i); total+=l.total();
                LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
                TextView t=tv((i+1)+". "+l.name+" | "+money(l.qty)+" "+l.unit+" × "+money(l.price)+" = "+money(l.total())+" افغانی",15);
                row.addView(t,new LinearLayout.LayoutParams(0,-2,1));
                Button del=btn("حذف"); row.addView(del,new LinearLayout.LayoutParams(dp(75),-2));
                final int idx=i; del.setOnClickListener(v->{cart.remove(idx);render[0].run();});
                cartBox.addView(row);
            }
            TextView sum=tv("جمع فاکتور: "+money(total)+" افغانی",18);
            sum.setTypeface(Typeface.DEFAULT,Typeface.BOLD); cartBox.addView(sum);
        };

        addLine.setOnClickListener(v->{
            long pid=id(sp); double q=n(qty); if(q<=0){Toast.makeText(this,"مقدار را وارد کنید",Toast.LENGTH_SHORT).show();return;}
            Cursor c=db.getReadableDatabase().rawQuery("SELECT name,unit,qty,buy,sell FROM products WHERE id="+pid,null);
            if(!c.moveToFirst()){c.close();return;}
            String nm=c.getString(0),unit=c.getString(1); double stock=c.getDouble(2),buy=c.getDouble(3),sell=c.getDouble(4);c.close();
            double already=0; for(SaleLine l:cart) if(l.pid==pid) already+=l.qty;
            if(q+already>stock){Toast.makeText(this,"موجودی کافی نیست: "+money(stock-already)+" "+unit+" باقی مانده",Toast.LENGTH_LONG).show();return;}
            double pr=n(price); if(pr<=0)pr=sell;
            cart.add(new SaleLine(pid,nm,unit,q,pr,buy)); qty.setText("");price.setText("");render[0].run();
        });

        EditText paid=input("مبلغ پرداختی مشتری"); content.addView(paid);
        Button save=btn("🧾 ثبت فاکتور و کم کردن همه اقلام از انبار"); content.addView(save);
        Button clear=btn("🗑️ فاکتور جدید / پاک کردن اقلام"); content.addView(clear);
        clear.setOnClickListener(v->{cart.clear();render[0].run();});

        save.setOnClickListener(v->{
            if(cart.isEmpty()){Toast.makeText(this,"حداقل یک کالا به فاکتور اضافه کنید",Toast.LENGTH_SHORT).show();return;}
            long cid=id(sc); double total=0; for(SaleLine l:cart) total+=l.total();
            double pa=Math.min(Math.max(0,n(paid)),total);
            SQLiteDatabase d=db.getWritableDatabase();
            String num="INV-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date());
            android.content.ContentValues iv=new android.content.ContentValues();
            iv.put("customer_id",cid);iv.put("number",num);iv.put("date",now());iv.put("total",total);iv.put("paid",pa);
            long iid=d.insert("invoices",null,iv);
            for(SaleLine l:cart){
                android.content.ContentValues sv=new android.content.ContentValues();
                sv.put("customer_id",cid);sv.put("product_id",l.pid);sv.put("qty",l.qty);sv.put("price",l.price);
                sv.put("total",l.total());sv.put("cost",l.qty*l.buy);sv.put("paid", (l==cart.get(0)?pa:0));sv.put("date",now());sv.put("invoice_id",iid);
                d.insert("sales",null,sv);
                Cursor st=d.rawQuery("SELECT qty FROM products WHERE id="+l.pid,null);st.moveToFirst();double stock=st.getDouble(0);st.close();
                android.content.ContentValues pv=new android.content.ContentValues();pv.put("qty",stock-l.qty);
                d.update("products",pv,"id=?",new String[]{""+l.pid});
            }
            String customer=customers().get((int)0).name;
            Cursor cc=d.rawQuery("SELECT name FROM customers WHERE id="+cid,null);if(cc.moveToFirst())customer=cc.getString(0);cc.close();
            StringBuilder receipt=new StringBuilder("حسابداری شرکت زراعتی عمر شاه محمدی\n");
            receipt.append("فاکتور: ").append(num).append("\nمشتری: ").append(customer).append("\nتاریخ: ").append(now()).append("\n\n");
            for(SaleLine l:cart) receipt.append(l.name).append(" | ").append(money(l.qty)).append(" ").append(l.unit).append(" × ").append(money(l.price)).append(" = ").append(money(l.total())).append(" افغانی\n");
            receipt.append("\nتعداد اقلام: ").append(cart.size()).append("\nجمع کل: ").append(money(total)).append(" افغانی\nپرداخت: ").append(money(pa)).append(" افغانی\nمانده: ").append(money(total-pa)).append(" افغانی");
            new AlertDialog.Builder(this).setTitle("فاکتور ثبت شد").setMessage(receipt.toString()).setPositiveButton("اشتراک‌گذاری", (a,w)->{
                Intent sh=new Intent(Intent.ACTION_SEND);sh.setType("text/plain");sh.putExtra(Intent.EXTRA_TEXT,receipt.toString());startActivity(Intent.createChooser(sh,"ارسال فاکتور"));
            }).setNegativeButton("بستن",null).show();
            cart.clear();showSales();
        });
    }

    void showPurchases(){
        base("ثبت خرید");
        ArrayList<KeyItem> ps=products();if(ps.size()==0){card("اول کالا را ثبت کنید.");return;}
        Spinner sp=spinner(ps);content.addView(tv("کالا",15));content.addView(sp);
        EditText qty=input("مقدار خرید");EditText buy=input("قیمت خرید هر واحد");content.addView(qty);content.addView(buy);
        Button add=btn("📦 ثبت خرید و اضافه کردن به انبار");content.addView(add);
        add.setOnClickListener(v->{long pid=id(sp);double q=n(qty),p=n(buy);if(q<=0||p<=0)return;
            SQLiteDatabase d=db.getWritableDatabase();Cursor c=d.rawQuery("SELECT qty FROM products WHERE id="+pid,null);c.moveToFirst();double stock=c.getDouble(0);c.close();
            android.content.ContentValues pv=new android.content.ContentValues();pv.put("qty",stock+q);pv.put("buy",p);d.update("products",pv,"id=?",new String[]{""+pid});
            android.content.ContentValues cv=new android.content.ContentValues();cv.put("product_id",pid);cv.put("qty",q);cv.put("buy",p);cv.put("total",q*p);cv.put("date",now());d.insert("purchases",null,cv);
            Toast.makeText(this,"خرید ثبت شد و موجودی اضافه شد.",Toast.LENGTH_LONG).show();showPurchases();
        });
    }

    void showReport(){
        base("گزارش سود و زیان");
        double sales=db.scalar("SELECT COALESCE(SUM(total),0) FROM sales"),cost=db.scalar("SELECT COALESCE(SUM(cost),0) FROM sales");
        double exp=db.scalar("SELECT COALESCE(SUM(amount),0) FROM expenses");
        card("فروش کل: "+money(sales)+" افغانی\nبهای جنس فروخته‌شده: "+money(cost)+" افغانی\nهزینه‌ها: "+money(exp)+" افغانی\nسود ناخالص: "+money(sales-cost)+" افغانی\nسود خالص: "+money(sales-cost-exp)+" افغانی");
    }
}
