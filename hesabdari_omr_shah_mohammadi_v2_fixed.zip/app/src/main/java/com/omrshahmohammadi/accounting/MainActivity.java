package com.omrshahmohammadi.accounting;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db;
    LinearLayout content;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        home();
    }

    TextView text(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.DKGRAY);
        t.setPadding(18,14,18,14); return t;
    }
    EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setTextSize(16); e.setPadding(16,8,16,8);
        return e;
    }
    Button button(String s) {
        Button b = new Button(this); b.setText(s); return b;
    }
    void page(String title) {
        LinearLayout all = new LinearLayout(this);
        all.setOrientation(LinearLayout.VERTICAL);
        TextView h = text(title,22);
        h.setTextColor(Color.WHITE); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        h.setBackgroundColor(Color.rgb(21,101,192));
        all.addView(h,new LinearLayout.LayoutParams(-1,70));
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(12,10,12,20); scroll.addView(content);
        all.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav = new LinearLayout(this);
        String[] names={"خانه","فروش","کالا","مشتری","خرید"};
        for(String n:names){
            Button b=button(n); nav.addView(b,new LinearLayout.LayoutParams(0,60,1));
            if(n.equals("خانه")) b.setOnClickListener(v->home());
            if(n.equals("فروش")) b.setOnClickListener(v->sales());
            if(n.equals("کالا")) b.setOnClickListener(v->products());
            if(n.equals("مشتری")) b.setOnClickListener(v->customers());
            if(n.equals("خرید")) b.setOnClickListener(v->purchases());
        }
        all.addView(nav);
        setContentView(all);
    }
    String fmt(double x){return String.format(Locale.US,"%.0f",x);}
    String date(){return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());}

    void home(){
        page("حسابداری عمر شاه محمدی");
        content.addView(text("داشبورد",25));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0) FROM sales",null); c.moveToFirst();
        double s=c.getDouble(0); c.close();
        c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0) FROM purchases",null); c.moveToFirst();
        double p=c.getDouble(0); c.close();
        content.addView(text("فروش کل: "+fmt(s)+" افغانی",19));
        content.addView(text("خرید کل: "+fmt(p)+" افغانی",19));
        content.addView(text("سود ناخالص: "+fmt(s-p)+" افغانی",20));
        Button r=button("گزارش سود و زیان"); r.setOnClickListener(v->report()); content.addView(r);
    }

    void products(){
        page("کالا و موجودی");
        EditText n=field("نام کالا"); EditText u=field("واحد"); EditText q=field("موجودی"); EditText bp=field("قیمت خرید");
        Button add=button("ثبت کالا");
        content.addView(n);content.addView(u);content.addView(q);content.addView(bp);content.addView(add);
        add.setOnClickListener(v->{
            try{
                db.getWritableDatabase().execSQL("INSERT INTO products(name,unit,qty,buy_price) VALUES(?,?,?,?)",
                    new Object[]{n.getText().toString(),u.getText().toString(),Double.parseDouble(q.getText().toString()),Double.parseDouble(bp.getText().toString())});
                Toast.makeText(this,"کالا ثبت شد",Toast.LENGTH_SHORT).show(); products();
            }catch(Exception e){Toast.makeText(this,"اطلاعات را کامل وارد کنید",Toast.LENGTH_SHORT).show();}
        });
        content.addView(text("موجودی فعلی",20));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,unit,qty,buy_price FROM products ORDER BY id DESC",null);
        while(c.moveToNext()) content.addView(text(c.getString(0)+" | "+fmt(c.getDouble(2))+" "+c.getString(1)+" | "+fmt(c.getDouble(3))+" افغانی",16));
        c.close();
    }

    void customers(){
        page("مشتریان");
        EditText n=field("نام مشتری"); EditText ph=field("شماره تلفن"); EditText ad=field("آدرس"); EditText bal=field("بدهی اولیه");
        Button add=button("ثبت مشتری");
        content.addView(n);content.addView(ph);content.addView(ad);content.addView(bal);content.addView(add);
        add.setOnClickListener(v->{
            try{
                double x=bal.getText().length()==0?0:Double.parseDouble(bal.getText().toString());
                db.getWritableDatabase().execSQL("INSERT INTO customers(name,phone,address,balance) VALUES(?,?,?,?)",
                    new Object[]{n.getText().toString(),ph.getText().toString(),ad.getText().toString(),x});
                Toast.makeText(this,"مشتری ثبت شد",Toast.LENGTH_SHORT).show(); customers();
            }catch(Exception e){Toast.makeText(this,"اطلاعات را کامل وارد کنید",Toast.LENGTH_SHORT).show();}
        });
        content.addView(text("حساب مشتریان",20));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,phone,balance FROM customers ORDER BY id DESC",null);
        while(c.moveToNext()) content.addView(text(c.getString(0)+" | "+c.getString(1)+" | مانده "+fmt(c.getDouble(2))+" افغانی",16));
        c.close();
    }

    void sales(){
        page("فروش نقدی / نسیه");
        EditText cu=field("نام مشتری (نقدی یا نام مشتری)"); EditText pr=field("نام کالا");
        EditText q=field("مقدار"); EditText price=field("قیمت فروش واحد"); EditText paid=field("دریافت");
        Button add=button("ثبت فروش");
        content.addView(cu);content.addView(pr);content.addView(q);content.addView(price);content.addView(paid);content.addView(add);
        add.setOnClickListener(v->{
            try{
                double qty=Double.parseDouble(q.getText().toString());
                double unit=Double.parseDouble(price.getText().toString());
                double pay=Double.parseDouble(paid.getText().toString());
                double total=qty*unit; String customer=cu.getText().toString();
                db.getWritableDatabase().execSQL("INSERT INTO sales(customer,product,qty,price,total,paid,date) VALUES(?,?,?,?,?,?,?)",
                    new Object[]{customer,pr.getText().toString(),qty,unit,total,pay,date()});
                db.getWritableDatabase().execSQL("UPDATE products SET qty=qty-? WHERE name=?",new Object[]{qty,pr.getText().toString()});
                if(!customer.equals("نقدی")) db.getWritableDatabase().execSQL("UPDATE customers SET balance=balance+? WHERE name=?",new Object[]{total-pay,customer});
                Toast.makeText(this,"فروش ثبت شد",Toast.LENGTH_SHORT).show(); sales();
            }catch(Exception e){Toast.makeText(this,"اطلاعات فروش را درست وارد کنید",Toast.LENGTH_SHORT).show();}
        });
        content.addView(text("آخرین فروش‌ها",20));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT customer,product,total,paid,date FROM sales ORDER BY id DESC LIMIT 20",null);
        while(c.moveToNext()) content.addView(text(c.getString(0)+" | "+c.getString(1)+" | "+fmt(c.getDouble(2))+" | دریافت "+fmt(c.getDouble(3)),15));
        c.close();
    }

    void purchases(){
        page("خرید از تأمین‌کننده");
        EditText su=field("نام تأمین‌کننده"); EditText pr=field("نام کالا");
        EditText q=field("مقدار"); EditText price=field("قیمت خرید واحد"); EditText paid=field("پرداخت");
        Button add=button("ثبت خرید");
        content.addView(su);content.addView(pr);content.addView(q);content.addView(price);content.addView(paid);content.addView(add);
        add.setOnClickListener(v->{
            try{
                double qty=Double.parseDouble(q.getText().toString());
                double unit=Double.parseDouble(price.getText().toString());
                double pay=Double.parseDouble(paid.getText().toString());
                double total=qty*unit;
                db.getWritableDatabase().execSQL("INSERT INTO purchases(supplier,product,qty,price,total,paid,date) VALUES(?,?,?,?,?,?,?)",
                    new Object[]{su.getText().toString(),pr.getText().toString(),qty,unit,total,pay,date()});
                db.getWritableDatabase().execSQL("UPDATE products SET qty=qty+? WHERE name=?",new Object[]{qty,pr.getText().toString()});
                Toast.makeText(this,"خرید ثبت شد",Toast.LENGTH_SHORT).show(); purchases();
            }catch(Exception e){Toast.makeText(this,"اطلاعات خرید را درست وارد کنید",Toast.LENGTH_SHORT).show();}
        });
        content.addView(text("آخرین خریدها",20));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT supplier,product,total,paid,date FROM purchases ORDER BY id DESC LIMIT 20",null);
        while(c.moveToNext()) content.addView(text(c.getString(0)+" | "+c.getString(1)+" | "+fmt(c.getDouble(2))+" | پرداخت "+fmt(c.getDouble(3)),15));
        c.close();
    }

    void report(){
        page("گزارش سود و زیان");
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(paid),0) FROM sales",null); c.moveToFirst();
        double s=c.getDouble(0), sp=c.getDouble(1); c.close();
        c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(paid),0) FROM purchases",null); c.moveToFirst();
        double p=c.getDouble(0), pp=c.getDouble(1); c.close();
        content.addView(text("فروش کل: "+fmt(s)+" افغانی",20));
        content.addView(text("خرید کل: "+fmt(p)+" افغانی",20));
        content.addView(text("سود ناخالص: "+fmt(s-p)+" افغانی",22));
        content.addView(text("مطالبات مشتریان: "+fmt(s-sp)+" افغانی",18));
        content.addView(text("بدهی به تأمین‌کنندگان: "+fmt(p-pp)+" افغانی",18));
    }

    static class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"accounting.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,unit TEXT,qty REAL,buy_price REAL)");
            d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,address TEXT,balance REAL)");
            d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,customer TEXT,product TEXT,qty REAL,price REAL,total REAL,paid REAL,date TEXT)");
            d.execSQL("CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,supplier TEXT,product TEXT,qty REAL,price REAL,total REAL,paid REAL,date TEXT)");
        }
        public void onUpgrade(SQLiteDatabase d,int oldV,int newV){}
    }
}
