package com.omrshahmohammadi.accounting;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private DB db;
    private LinearLayout body;
    private final int green = Color.rgb(22, 131, 75);
    private final int dark = Color.rgb(24, 53, 42);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        buildShell();
        home();
    }

    private int dp(int v){ return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void buildShell() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(247,250,248));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout vertical = new LinearLayout(this);
        vertical.setOrientation(LinearLayout.VERTICAL);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(12),dp(8),dp(12),dp(8));
        head.setBackgroundColor(Color.rgb(20,117,83));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.app_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        head.addView(logo, new LinearLayout.LayoutParams(dp(58),dp(58)));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(10),0,0,0);
        titles.addView(tv("حسابداری شرکت زراعتی عمر شاه محمدی",20,Color.WHITE,true));
        titles.addView(tv("سم و کود زراعتی • افغانی • نسخه حرفه‌ای",12,Color.WHITE,false));
        head.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        vertical.addView(head,new LinearLayout.LayoutParams(-1,dp(72)));

        FrameLayout content = new FrameLayout(this);
        ImageView wm = new ImageView(this);
        wm.setImageResource(R.drawable.logo_watermark);
        wm.setAlpha(0.12f);
        wm.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        content.addView(wm,new FrameLayout.LayoutParams(-1,-1));
        ScrollView scroll = new ScrollView(this);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14),dp(14),dp(14),dp(24));
        body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(body);
        content.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
        vertical.addView(content,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(Color.WHITE);
        String[][] items={{"خانه","⌂"},{"فروش","🧾"},{"انبار","📦"},{"مشتریان","👥"},{"گزارش","📊"}};
        for(String[] item:items){
            Button x=button(item[1]+"\n"+item[0],()->{
                switch(item[0]){case "خانه":home();break;case "فروش":sales();break;case "انبار":inventory();break;case "مشتریان":customers();break;default:reports();}
            });
            x.setTextSize(15); x.setTextColor(dark); x.setBackgroundColor(Color.TRANSPARENT);
            nav.addView(x,new LinearLayout.LayoutParams(0,dp(72),1));
        }
        vertical.addView(nav,new LinearLayout.LayoutParams(-1,dp(72)));
        root.addView(vertical,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
    }

    private void clear(String title){
        body.removeAllViews();
        TextView t=tv(title,24,dark,true); t.setGravity(Gravity.CENTER_HORIZONTAL); body.addView(t);
        TextView s=tv("حسابداری شرکت زراعتی عمر شاه محمدی",12,Color.rgb(90,130,110),false); s.setGravity(Gravity.CENTER_HORIZONTAL); body.addView(s);
        space(8);
    }
    private TextView tv(String s,float size,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setPadding(dp(4),dp(5),dp(4),dp(5));if(bold)v.setTypeface(null,1);return v;}
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(18);e.setMinHeight(dp(60));e.setPadding(dp(14),dp(10),dp(14),dp(10));e.setBackgroundColor(Color.WHITE);return e;}
    private Button button(String s,final Runnable action){Button b=new Button(this);b.setText(s);b.setTextSize(16);b.setMinHeight(dp(54));b.setPadding(dp(8),dp(6),dp(8),dp(6));b.setOnClickListener(v->action.run());return b;}
    private void space(int h){body.addView(new Space(this),new LinearLayout.LayoutParams(1,dp(h)));}
    private void card(View v){LinearLayout box=new LinearLayout(this);box.setPadding(dp(12),dp(8),dp(12),dp(8));box.setBackgroundColor(Color.WHITE);box.addView(v);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(10));body.addView(box,p);}
    private String money(double x){return String.format(Locale.US,"%,.0f افغانی",x);}
    private int count(String table){Cursor c=db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);try{c.moveToFirst();return c.getInt(0);}finally{c.close();}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}

    private void home(){
        clear("داشبورد"); double sales=0,debt=0;
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(total-paid),0) FROM sales",null);
        if(c.moveToFirst()){sales=c.getDouble(0);debt=c.getDouble(1);}c.close();
        card(tv("💰 فروش کل\n"+money(sales),18,dark,true));
        card(tv("🔴 طلب مشتریان\n"+money(debt),18,Color.rgb(170,40,40),true));
        card(tv("📦 کالا: "+count("products")+"     👥 مشتری: "+count("customers"),16,dark,true));
        body.addView(button("＋ ثبت فروش و صدور فاکتور",this::sales),new LinearLayout.LayoutParams(-1,dp(58)));
        body.addView(button("＋ ثبت کالای جدید",this::newProduct),new LinearLayout.LayoutParams(-1,dp(58)));
        body.addView(button("＋ ثبت خرید و ورود کالا به انبار",this::purchaseStock),new LinearLayout.LayoutParams(-1,dp(58)));
        body.addView(button("＋ ثبت مشتری جدید",this::newCustomer),new LinearLayout.LayoutParams(-1,dp(58)));
        body.addView(button("☁ پشتیبان‌گیری و ارسال به جیمیل",this::backup),new LinearLayout.LayoutParams(-1,dp(58)));
    }

    private void sales(){
        clear("ثبت فروش و صدور فاکتور چندقلمی");
        Spinner customer=new Spinner(this); List<String> names=new ArrayList<>(); names.add("مشتری نقدی");
        Cursor cc=db.getReadableDatabase().rawQuery("SELECT name FROM customers ORDER BY name",null);while(cc.moveToNext())names.add(cc.getString(0));cc.close();
        customer.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names)); body.addView(tv("مشتری",13,dark,false));body.addView(customer);
        Spinner product=new Spinner(this);List<String> prods=new ArrayList<>();List<Long> ids=new ArrayList<>();List<Double> prices=new ArrayList<>();
        Cursor pc=db.getReadableDatabase().rawQuery("SELECT id,name,sell FROM products ORDER BY name",null);while(pc.moveToNext()){ids.add(pc.getLong(0));prods.add(pc.getString(1));prices.add(pc.getDouble(2));}pc.close();
        product.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,prods.isEmpty()?Collections.singletonList("ابتدا کالا ثبت کنید"):prods));
        body.addView(tv("محصول",13,dark,false));body.addView(product);
        EditText qty=field("تعداد");qty.setInputType(2); EditText price=field("قیمت فروش واحد");price.setInputType(2);body.addView(qty,new LinearLayout.LayoutParams(-1,dp(62))); space(14); body.addView(price,new LinearLayout.LayoutParams(-1,dp(62))); space(18);
        List<Line> cart=new ArrayList<>();LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        body.addView(button("＋ افزودن کالا به فاکتور",()->{
            if(prods.isEmpty()){toast("ابتدا کالا ثبت کنید");return;}
            double q=parse(qty.getText().toString()),p=parse(price.getText().toString());if(p<=0)p=prices.get(product.getSelectedItemPosition());
            if(q<=0||p<=0){toast("تعداد و قیمت را وارد کنید");return;}
            cart.add(new Line(product.getSelectedItem().toString(),q,p,ids.get(product.getSelectedItemPosition())));renderCart(list,cart);qty.setText("");
        }));
        body.addView(list); EditText paid=field("مبلغ پرداختی");paid.setInputType(2);body.addView(paid);
        Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,Arrays.asList("نقدی","قرضی")));body.addView(type);
        body.addView(button("🧾 ثبت فاکتور",()->{
            if(cart.isEmpty()){toast("حداقل یک کالا اضافه کنید");return;}
            double total=0;for(Line l:cart)total+=l.qty*l.price;double pay=type.getSelectedItemPosition()==0?total:parse(paid.getText().toString());
            String invoice="INV-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date());SQLiteDatabase d=db.getWritableDatabase();d.beginTransaction();
            try{boolean first=true;for(Line l:cart){double line=l.qty*l.price;double linePaid=first?pay:0;d.execSQL("INSERT INTO sales(customer,product,qty,price,total,paid,type,date,invoiceNo) VALUES(?,?,?,?,?,?,?,?,?)",new Object[]{customer.getSelectedItem().toString(),l.name,l.qty,l.price,line,linePaid,type.getSelectedItem().toString(),today(),invoice});d.execSQL("UPDATE products SET qty=MAX(0,qty-?) WHERE id=?",new Object[]{l.qty,l.id});first=false;}d.setTransactionSuccessful();toast("فاکتور "+invoice+" ثبت شد");home();}finally{d.endTransaction();}
        }));
    }

    private void renderCart(LinearLayout list,List<Line> cart){list.removeAllViews();double total=0;for(int i=0;i<cart.size();i++){Line l=cart.get(i);double line=l.qty*l.price;total+=line;LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setOrientation(LinearLayout.HORIZONTAL);row.addView(tv((i+1)+". "+l.name+" | "+l.qty+" × "+money(l.price)+" = "+money(line),14,dark,false),new LinearLayout.LayoutParams(0,-2,1));final int idx=i;row.addView(button("حذف",()->{cart.remove(idx);renderCart(list,cart);}));list.addView(row);}if(!cart.isEmpty())list.addView(tv("جمع فاکتور: "+money(total),16,green,true));}

    private void inventory(){clear("انبار سم و کود");body.addView(button("＋ ثبت کالای جدید",this::newProduct),new LinearLayout.LayoutParams(-1,dp(58)));
        body.addView(button("📥 ثبت خرید / ورود کالا",this::purchaseStock),new LinearLayout.LayoutParams(-1,dp(60)));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,type,unit,qty,buy,sell FROM products ORDER BY name",null);if(!c.moveToFirst())body.addView(tv("هنوز کالایی ثبت نشده است.",15,Color.GRAY,false));else do{card(tv(c.getString(0)+"\n"+c.getString(1)+" • "+c.getDouble(3)+" "+c.getString(2)+"\nخرید: "+money(c.getDouble(4))+" | فروش: "+money(c.getDouble(5)),15,dark,false));}while(c.moveToNext());c.close();}

    private void purchaseStock(){
        Cursor pc=db.getReadableDatabase().rawQuery("SELECT id,name,unit,buy FROM products ORDER BY name",null);
        ArrayList<Long> ids=new ArrayList<>(); ArrayList<String> names=new ArrayList<>(); ArrayList<String> units=new ArrayList<>(); ArrayList<Double> oldBuy=new ArrayList<>();
        while(pc.moveToNext()){ids.add(pc.getLong(0));names.add(pc.getString(1));units.add(pc.getString(2));oldBuy.add(pc.getDouble(3));} pc.close();
        if(names.isEmpty()){toast("ابتدا کالا را ثبت کنید");return;}
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(10),dp(20),dp(5));
        Spinner product=new Spinner(this); product.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names)); box.addView(tv("انتخاب کالا",15,dark,true)); box.addView(product);
        EditText qty=field("مقدار خرید / تعداد واردشده"); qty.setInputType(2); box.addView(qty);
        EditText cost=field("قیمت خرید واحد"); cost.setInputType(2); box.addView(cost);
        EditText supplier=field("نام فروشنده / شرکت (اختیاری)"); box.addView(supplier);
        new AlertDialog.Builder(this).setTitle("ثبت خرید و ورود کالا به انبار").setView(box).setPositiveButton("ثبت خرید",(dlg,w)->{
            int pos=product.getSelectedItemPosition(); double q=parse(qty.getText().toString()); double c=parse(cost.getText().toString());
            if(q<=0){toast("مقدار خرید را وارد کنید");return;}
            if(c<=0)c=oldBuy.get(pos); if(c<=0){toast("قیمت خرید را وارد کنید");return;}
            SQLiteDatabase d=db.getWritableDatabase(); d.beginTransaction();
            try{
                d.execSQL("UPDATE products SET qty=qty+?, buy=? WHERE id=?",new Object[]{q,c,ids.get(pos)});
                d.execSQL("INSERT INTO purchases(product_id,product,qty,cost,supplier,date,total) VALUES(?,?,?,?,?,?,?)",new Object[]{ids.get(pos),names.get(pos),q,c,supplier.getText().toString(),today(),q*c});
                d.setTransactionSuccessful(); toast("خرید ثبت شد و "+q+" "+units.get(pos)+" به انبار اضافه شد"); inventory();
            }finally{d.endTransaction();}
        }).setNegativeButton("لغو",null).show();
    }

    private void newProduct(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(20,10,20,5);EditText n=field("نام محصول"),type=field("نوع: سم یا کود"),unit=field("واحد: بوتل، کیلو، بوجی..."),qty=field("موجودی اولیه"),buy=field("قیمت خرید واحد"),sell=field("قیمت فروش واحد");for(EditText e:new EditText[]{n,type,unit,qty,buy,sell})box.addView(e);
        new AlertDialog.Builder(this).setTitle("ثبت کالای جدید").setView(box).setPositiveButton("ثبت",(d,w)->{db.getWritableDatabase().execSQL("INSERT INTO products(name,type,unit,qty,buy,sell) VALUES(?,?,?,?,?,?)",new Object[]{n.getText().toString(),type.getText().toString(),unit.getText().toString(),parse(qty.getText().toString()),parse(buy.getText().toString()),parse(sell.getText().toString())});inventory();}).setNegativeButton("لغو",null).show();
    }

    private void customers(){
        clear("مشتریان و حساب‌های قرضی");body.addView(button("＋ ثبت مشتری جدید",this::newCustomer),new LinearLayout.LayoutParams(-1,dp(58)));body.addView(button("☁ پشتیبان‌گیری و ارسال به جیمیل",this::backup),new LinearLayout.LayoutParams(-1,dp(58)));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,phone,address,accountType,initialDebt FROM customers ORDER BY name",null);if(!c.moveToFirst())body.addView(tv("هنوز مشتری ثبت نشده است.",15,Color.GRAY,false));else do{final long id=c.getLong(0);LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);v.addView(tv("👤 "+c.getString(1),17,dark,true));v.addView(tv("شماره: "+c.getString(2)+"\nآدرس: "+c.getString(3)+"\nنوع حساب: "+c.getString(4)+"\nبدهی اولیه: "+money(c.getDouble(5)),14,dark,false));
            LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button receiptBtn=button("🧾 ثبت رسید پرداخت",()->recordPayment(id)); receiptBtn.setTextSize(15);
            Button detailsBtn=button("📒 مشخصات و گردش حساب",()->customerDetails(id)); detailsBtn.setTextSize(15);
            actions.addView(receiptBtn,new LinearLayout.LayoutParams(0,dp(58),1));
            actions.addView(detailsBtn,new LinearLayout.LayoutParams(0,dp(58),1));
            v.addView(actions);card(v);}while(c.moveToNext());c.close();
    }

    private void newCustomer(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(20,10,20,5);EditText n=field("نام مشتری"),phone=field("شماره تماس"),addr=field("آدرس"),type=field("نوع حساب: نقدی یا قرضی"),debt=field("مبلغ اولیه بدهی");for(EditText e:new EditText[]{n,phone,addr,type,debt})box.addView(e);
        new AlertDialog.Builder(this).setTitle("ثبت مشتری جدید").setView(box).setPositiveButton("ثبت",(d,w)->{db.getWritableDatabase().execSQL("INSERT INTO customers(name,phone,address,accountType,initialDebt) VALUES(?,?,?,?,?)",new Object[]{n.getText().toString(),phone.getText().toString(),addr.getText().toString(),type.getText().toString(),parse(debt.getText().toString())});customers();}).setNegativeButton("لغو",null).show();
    }

    private void customerDetails(long id){
        String name="",phone="",address="";double initial=0;Cursor c=db.getReadableDatabase().rawQuery("SELECT name,phone,address,initialDebt FROM customers WHERE id=?",new String[]{String.valueOf(id)});if(c.moveToFirst()){name=c.getString(0);phone=c.getString(1);address=c.getString(2);initial=c.getDouble(3);}c.close();clear("گردش حساب: "+name);card(tv("👤 نام: "+name+"\n📞 شماره: "+phone+"\n📍 آدرس: "+address+"\n💰 بدهی اولیه: "+money(initial),16,dark,true));
        double total=initial,paid=0;Cursor s=db.getReadableDatabase().rawQuery("SELECT product,qty,total,paid,type,date,invoiceNo FROM sales WHERE customer=? ORDER BY id DESC",new String[]{name});while(s.moveToNext()){total+=s.getDouble(2);paid+=s.getDouble(3);card(tv("🧾 "+s.getString(6)+" | "+s.getString(5)+"\nجنس: "+s.getString(0)+"\nتعداد: "+s.getDouble(1)+" | مبلغ: "+money(s.getDouble(2))+"\nپرداخت: "+money(s.getDouble(3))+" | "+s.getString(4),14,dark,false));}s.close();
        Cursor p=db.getReadableDatabase().rawQuery("SELECT amount,date,method FROM payments WHERE customer=? ORDER BY id DESC",new String[]{name});while(p.moveToNext()){paid+=p.getDouble(0);card(tv("💵 دریافت پرداخت\n"+p.getString(1)+" | "+p.getString(2)+"\nمبلغ: "+money(p.getDouble(0)),14,green,false));}p.close();card(tv("جمع بدهی/خرید: "+money(total)+"\nجمع پرداخت‌ها: "+money(paid)+"\nمانده حساب: "+money(Math.max(0,total-paid)),18,dark,true));
        body.addView(button("🧾 ثبت رسید پرداخت جدید",()->recordPayment(id)),new LinearLayout.LayoutParams(-1,dp(60)));
        body.addView(button("← برگشت به مشتریان",this::customers));
    }

    private void recordPayment(long id){
        String name=""; double initial=0, salesTotal=0, salesPaid=0, previousPayments=0;
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,initialDebt FROM customers WHERE id=?",new String[]{String.valueOf(id)});
        if(c.moveToFirst()){name=c.getString(0);initial=c.getDouble(1);} c.close();
        Cursor s=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(paid),0) FROM sales WHERE customer=?",new String[]{name});
        if(s.moveToFirst()){salesTotal=s.getDouble(0);salesPaid=s.getDouble(1);} s.close();
        Cursor pp=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments WHERE customer=?",new String[]{name});
        if(pp.moveToFirst())previousPayments=pp.getDouble(0); pp.close();
        final double balance=Math.max(0,initial+salesTotal-salesPaid-previousPayments);

        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(8),dp(18),dp(4));
        box.addView(tv("مشتری: "+name+"\nمانده فعلی: "+money(balance),16,dark,true));
        EditText amount=field("مبلغ پرداختی"); amount.setInputType(2); box.addView(amount);
        EditText date=field("تاریخ (مثلاً 1405-07-04)"); date.setText(today()); box.addView(date);
        Spinner method=new Spinner(this); method.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,Arrays.asList("نقدی","حواله بانکی","چک","کارت","سایر"))); box.addView(tv("روش پرداخت",14,dark,true)); box.addView(method);
        new AlertDialog.Builder(this).setTitle("🧾 رسید پرداخت مشتری").setView(box).setPositiveButton("ثبت رسید",(dlg,w)->{
            double a=parse(amount.getText().toString());
            if(a<=0){toast("مبلغ پرداختی را وارد کنید");return;}
            if(a>balance+0.0001){toast("مبلغ پرداختی بیشتر از مانده حساب است");return;}
            SQLiteDatabase d=db.getWritableDatabase(); d.execSQL("INSERT INTO payments(customer,amount,date,method) VALUES(?,?,?,?)",new Object[]{name,a,date.getText().toString().trim(),method.getSelectedItem().toString()});
            toast("رسید پرداخت ثبت شد؛ "+money(a)+" از مانده حساب کم شد"); customerDetails(id);
        }).setNegativeButton("لغو",null).show();
    }

    private void backup(){
        StringBuilder sb=new StringBuilder();sb.append("پشتیبان حسابداری شرکت زراعتی عمر شاه محمدی\nتاریخ: ").append(today()).append("\n\n");SQLiteDatabase d=db.getReadableDatabase();appendTable(sb,"محصولات","SELECT id,name,type,unit,qty,buy,sell FROM products",d);appendTable(sb,"مشتریان","SELECT id,name,phone,address,accountType,initialDebt FROM customers",d);appendTable(sb,"فروش و فاکتورها","SELECT id,customer,product,qty,price,total,paid,type,date,invoiceNo FROM sales",d);appendTable(sb,"پرداخت‌ها","SELECT id,customer,amount,date,method FROM payments",d);appendTable(sb,"خریدها","SELECT id,product,qty,cost,supplier,date,total FROM purchases",d);
        try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"پشتیبان حسابداری - "+today());i.putExtra(Intent.EXTRA_TEXT,sb.toString());startActivity(Intent.createChooser(i,"ارسال پشتیبان با جیمیل یا واتساپ"));}catch(Exception e){toast("ارسال پشتیبان انجام نشد: "+e.getMessage());}
    }
    private void appendTable(StringBuilder sb,String title,String sql,SQLiteDatabase d){sb.append("=== ").append(title).append(" ===\n");Cursor c=d.rawQuery(sql,null);while(c.moveToNext()){for(int i=0;i<c.getColumnCount();i++){if(i>0)sb.append(" | ");sb.append(c.getString(i)==null?"":c.getString(i));}sb.append("\n");}c.close();sb.append("\n");}

    private void reports(){clear("گزارش سود و زیان");double sales=0,cost=0;Cursor c=db.getReadableDatabase().rawQuery("SELECT product,qty,total FROM sales",null);while(c.moveToNext()){sales+=c.getDouble(2);Cursor p=db.getReadableDatabase().rawQuery("SELECT buy FROM products WHERE name=?",new String[]{c.getString(0)});if(p.moveToFirst())cost+=p.getDouble(0)*c.getDouble(1);p.close();}c.close();card(tv("مجموع فروش\n"+money(sales),18,dark,true));card(tv("بهای کالاهای فروخته‌شده\n"+money(cost),18,dark,true));card(tv("سود ناخالص\n"+money(sales-cost),20,green,true));}
    private double parse(String s){try{return Double.parseDouble(s.replace(",",""));}catch(Exception e){return 0;}}

    private static class Line{String name;double qty,price;long id;Line(String n,double q,double p,long i){name=n;qty=q;price=p;id=i;}}
    private static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"accounting.db",null,5);}
        @Override public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,type TEXT,unit TEXT,qty REAL,buy REAL,sell REAL)");d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,address TEXT,accountType TEXT,initialDebt REAL)");d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,customer TEXT,product TEXT,qty REAL,price REAL,total REAL,paid REAL,type TEXT,date TEXT,invoiceNo TEXT)");d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,customer TEXT,amount REAL,date TEXT,method TEXT)");d.execSQL("CREATE TABLE app_meta(id INTEGER PRIMARY KEY,value TEXT)");d.execSQL("CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,product TEXT,qty REAL,cost REAL,supplier TEXT,date TEXT,total REAL)");}
        @Override public void onUpgrade(SQLiteDatabase d,int oldV,int newV){if(oldV<2){try{d.execSQL("ALTER TABLE sales ADD COLUMN invoiceNo TEXT DEFAULT ''");}catch(Exception ignored){}}if(oldV<3)d.execSQL("CREATE TABLE IF NOT EXISTS app_meta(id INTEGER PRIMARY KEY,value TEXT)");if(oldV<4)d.execSQL("CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT,customer TEXT,amount REAL,date TEXT,method TEXT)");if(oldV<5)d.execSQL("CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,product TEXT,qty REAL,cost REAL,supplier TEXT,date TEXT,total REAL)");}
    }
}
